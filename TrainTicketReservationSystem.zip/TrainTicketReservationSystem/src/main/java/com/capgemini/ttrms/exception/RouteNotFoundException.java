package com.capgemini.ttrms.exception;

public class RouteNotFoundException extends RuntimeException{
	public  RouteNotFoundException(String msg) {
		super(msg);
	}
}
