package com.capgemini.ttrms.exception;

public class AdminNotFoundException extends RuntimeException{
	
	public  AdminNotFoundException(String msg) {
		super(msg);
	}
}
