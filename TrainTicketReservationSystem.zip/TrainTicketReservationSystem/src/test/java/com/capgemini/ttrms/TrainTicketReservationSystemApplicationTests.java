package com.capgemini.ttrms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainTicketReservationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
